<div class="modal modal-blur fade" id="success-alert" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
                <div class="alert alert-success alert-dismissible" role="alert">
                    <h3 class="alert-title">Wow! 'Category Title' category  created successfully!</h3>
                    <p>Now you can add content to this 'category title' .</p>
                    <div class="btn-list">
                        <a href="javascript:void(0)" class="btn btn-success">Okay</a>
                        <a href="javascript:void(0)" class="btn">Cancel</a>
                    </div>
                    <a class="btn-close" data-bs-dismiss="alert" aria-label="close"></a>
                </div>
    </div>
</div><?php /**PATH E:\Development\Web-Development\xampp\htdocs\ContentDashBoard\resources\views/live/coloringbook/modals/sucess-alert.blade.php ENDPATH**/ ?>