<div class="modal modal-blur fade" id="success-alert-content" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
                <div class="alert alert-success alert-dismissible" role="alert">
                    <h3 class="alert-title">Wow! Content is successfully added to 'Category Title' category</h3>
                    <div class="btn-list">
                        <a href="javascript:void(0)" class="btn btn-success">Okay</a>
                        <a href="javascript:void(0)" class="btn">Cancel</a>
                    </div>
                    <a class="btn-close" data-bs-dismiss="alert" aria-label="close"></a>
                </div>
    </div>
</div><?php /**PATH E:\Development\Web-Development\xampp\htdocs\ContentDashBoard\resources\views/live/coloringbook/modals/content/sucess-alert-content.blade.php ENDPATH**/ ?>