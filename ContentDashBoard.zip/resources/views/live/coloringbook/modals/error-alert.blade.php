<div class="modal modal-blur fade" id="error-alert" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <h3 class="alert-title">Opps! There is some error in creating 'Category Title' category !</h3>
                    <p>Error description based on user input. It may be like</p>
                    <p>Please add slider thumbnail</p>
                    <p>Category title is too long</p>
                    <div class="btn-list">
                        <a href="javascript:void(0)" class="btn btn-danger">Okay</a>
                        <a href="javascript:void(0)" class="btn">Cancel</a>
                    </div>
                    <a class="btn-close" data-bs-dismiss="alert" aria-label="close"></a>
                </div>
    </div>
</div>